##微信小程序SDK DEMO

###微信小程序使用方法详见 http://lbs.amap.com/api/wx/summary